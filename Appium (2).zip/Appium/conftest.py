import pytest
from appium import webdriver

@pytest.fixture(scope='function')
def driver():
    desired_caps = {
        "platformName": "Android",
        "platformVersion": "9.0",
        "deviceName": "Android Emulator",
        "app": "/path/to/ApiDemos-debug.apk",
        "automationName": "UiAutomator2"
    }
    driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
    yield driver
    driver.quit()
