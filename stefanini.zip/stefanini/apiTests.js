const axios = require('axios');
const chai = require('chai');
const expect = chai.expect;

const baseURL = 'https://jsonplaceholder.typicode.com';

describe('API Placeholder Tests', function() {

    it('should validate GET /posts', async function() {
        const response = await axios.get(`${baseURL}/posts`);
        expect(response.status).to.equal(200);
        expect(response.data).to.be.an('array');
        response.data.forEach(post => {
            expect(post).to.have.all.keys('userId', 'id', 'title', 'body');
        });
    });

    it('should validate POST /posts', async function() {
        const response = await axios.post(`${baseURL}/posts`, {
            title: 'foo',
            body: 'bar',
            userId: 1
        });
        expect(response.status).to.equal(201);
        expect(response.data).to.have.all.keys('userId', 'id', 'title', 'body');
    });

    it('should validate PUT /posts/1', async function() {
        const response = await axios.put(`${baseURL}/posts/1`, {
            id: 1,
            title: 'foo',
            body: 'bar',
            userId: 1
        });
        expect(response.status).to.equal(200);
        expect(response.data).to.have.all.keys('userId', 'id', 'title', 'body');
    });

    it('should validate DELETE /posts/1', async function() {
        const response = await axios.delete(`${baseURL}/posts/1`);
        expect(response.status).to.equal(200);
    });

});
